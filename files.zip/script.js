import * as THREE from 'three';
import {Sky} from 'three/examples/jsm/objects/Sky.js';
import {EffectComposer} from 'three/examples/jsm/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/examples/jsm/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/examples/jsm/postprocessing/OutputPass.js';
import {ShaderPass} from 'three/examples/jsm/postprocessing/ShaderPass.js';
import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';

/* ---------- settings (edit these) ---------- */
const ZE = 64;               // distance from start to the gazebo centre (metres)
const S_START = 1.2;         // where the walk begins
let finalS = ZE - 2.2;       // where the camera stops, in front of the invitation (set in resize)
const DUR = 34000;           // whole journey in milliseconds: walk + slow approach to the invitation
const MUSIC_SRC = '/music.mp3'; // put your audio file in the public folder
const CAM_H = 1.62;          // eye height
const COARSE = matchMedia('(pointer:coarse)').matches;
const Q = COARSE ? 0.55 : 1; // density multiplier for phones/tablets
const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- helpers ---------- */
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const sm = t => { t = clamp(t); return t * t * (3 - 2 * t); };
const rng = s => () => { s |= 0; s = s + 0x6D2B79F5 | 0; let t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const R = rng(5), rr = (a, b) => a + (b - a) * R();
const hash = (a, b) => { const h = Math.sin(a * 127.1 + b * 311.7) * 43758.5453; return h - Math.floor(h); };
const pick = a => a[Math.floor(R() * a.length)];
function pathX(s) { const k = 1 - sm((s - 34) / 20); return k * (3.2 * Math.sin(s * .13) + 1.3 * Math.sin(s * .31 + 1.3)); }
const dX = s => (pathX(s + .05) - pathX(s - .05)) / .1;
function lat(s, off) { const d = dX(s), n = Math.hypot(1, d); return [pathX(s) + off / n, -s + off * d / n]; }
const bad = (x, z) => Math.abs(x) < 3.4 && Math.abs(z + ZE) < 3.7;
function canvasTex(w, h, draw, rep, srgb = true) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rep[0], rep[1]); t.anisotropy = 8;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace; return t;
}

/* ---------- renderer, sky, light ---------- */
const canvas = document.getElementById('c');
const renderer = new THREE.WebGLRenderer({canvas, antialias: false, powerPreference: 'high-performance'});
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = .62;
const scene = new THREE.Scene(); scene.fog = new THREE.FogExp2(0xe4d6bf, .0115);
const camera = new THREE.PerspectiveCamera(50, 1, .1, 3000);
const sunDir = new THREE.Vector3(.62, .36, -.38).normalize();
const sun = new THREE.DirectionalLight(0xffd6a0, 3.8); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, {left: -30, right: 30, top: 30, bottom: -30, near: 1, far: 170});
sun.shadow.bias = -.0004; sun.shadow.normalBias = .04; scene.add(sun, sun.target);
scene.add(new THREE.HemisphereLight(0xc4d4e8, 0x7a6a3a, 1.0));
const sky = new Sky(); sky.scale.setScalar(2500); scene.add(sky);
Object.assign(sky.material.uniforms, {});
const su = sky.material.uniforms; su.turbidity.value = 6; su.rayleigh.value = 2; su.mieCoefficient.value = .008; su.mieDirectionalG.value = .88; su.sunPosition.value.copy(sunDir);
const puff = canvasTex(256, 256, (c, w, h) => { for (let i = 0; i < 26; i++) { const x = rr(60, 196), y = rr(100, 156), r = rr(30, 60), g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h); } }, [1, 1]);
for (let i = 0; i < 9; i++) { const sp = new THREE.Sprite(new THREE.SpriteMaterial({map: puff, fog: false, depthWrite: false, opacity: rr(.5, .85)})); sp.material.color.set(2.7, 2.4, 2.0); sp.position.set(rr(-900, 900), rr(180, 330), rr(-1000, -500)); sp.scale.set(rr(300, 520), rr(110, 200), 1); scene.add(sp); }

/* ---------- wind + material patching ---------- */
const U = {uTime: {value: 0}};
function patch(mat, mode) {
  mat.customProgramCacheKey = () => mode;
  mat.onBeforeCompile = sh => {
    sh.uniforms.uTime = U.uTime;
    let v = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime;' + (mode === 'plant' ? '\nattribute float aKeep;' : ''));
    if (mode === 'plant') v = v.replace('#include <color_vertex>', '#include <color_vertex>\nvColor.rgb = mix(vColor.rgb, color.rgb, aKeep);');
    v = v.replace('#include <begin_vertex>', `#include <begin_vertex>
      vec2 ip = instanceMatrix[3].xz; float ph = ip.x*.7 + ip.y*.5;
      float gust = .6 + .4*sin(uTime*.5 + ip.x*.1 + ip.y*.08);
      float w = (sin(uTime*1.7 + ph)*.6 + sin(uTime*2.9 + ph*1.7)*.25) * gust;
      ${mode === 'plant' ? 'float hh = max(position.y, 0.); transformed.x += w*hh*hh*.14; transformed.z += w*hh*hh*.07;' : 'transformed.x += w*.035; transformed.y += w*.012;'}`);
    sh.vertexShader = v;
  };
}
const dm = new THREE.Object3D();
function build(geo, mat, items, shadow = false) {
  const m = new THREE.InstancedMesh(geo, mat, items.length);
  items.forEach((it, i) => {
    dm.position.set(it.x, it.y || 0, it.z);
    if (it.q) dm.quaternion.copy(it.q); else dm.rotation.set(it.rx || 0, it.ry || 0, it.rz || 0);
    const sx = it.sx ?? it.s, sy = it.sy ?? it.s; dm.scale.set(sx, sy, sx); dm.updateMatrix();
    m.setMatrixAt(i, dm.matrix); if (it.c) m.setColorAt(i, it.c);
  });
  m.instanceMatrix.needsUpdate = true; m.receiveShadow = true; m.castShadow = shadow; m.frustumCulled = false; scene.add(m); return m;
}

/* ---------- ground + path ---------- */
const grassTex = canvasTex(512, 512, (c, w, h) => {
  c.fillStyle = '#5b8a3a'; c.fillRect(0, 0, w, h);
  const cols = ['#4a7a30', '#6a9a45', '#7aaa50', '#3f6b2b', '#88b35a'];
  for (let i = 0; i < 14000; i++) { c.strokeStyle = pick(cols); c.globalAlpha = rr(.25, .6); c.lineWidth = rr(.8, 1.8); const x = rr(0, w), y = rr(0, h), a = rr(0, 6.28), l = rr(5, 13); c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); c.stroke(); }
}, [75, 75]);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(320, 320).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({map: grassTex, roughness: 1}));
ground.position.set(0, 0, -50); ground.receiveShadow = true; scene.add(ground);

const pathTex = canvasTex(512, 512, (c, w, h) => {
  c.fillStyle = '#d6c39b'; c.fillRect(0, 0, w, h);
  for (let i = 0; i < 7000; i++) { c.fillStyle = pick(['#c4b189', '#e2d2ac', '#b9a77f', '#d0be94']); c.globalAlpha = .5; c.fillRect(rr(0, w), rr(0, h), rr(1, 3), rr(1, 3)); }
  c.globalAlpha = 1;
  for (let i = 0; i < 650; i++) { const x = rr(0, w), y = rr(0, h), r = rr(2, 6); c.fillStyle = 'rgba(70,55,35,.35)'; c.beginPath(); c.ellipse(x + 1.5, y + 2, r, r * .75, 0, 0, 7); c.fill(); c.fillStyle = pick(['#bfae88', '#e6d8b4', '#a99a78', '#cfc1a0', '#f0e4c4']); c.beginPath(); c.ellipse(x, y, r, r * .75, rr(0, 3), 0, 7); c.fill(); }
}, [1, 1]);
pathTex.repeat.set(1, 1);
{
  const N = Math.floor((ZE - 3) / .5), pos = [], uv = [], idx = [];
  for (let i = 0; i <= N; i++) { const s = i * .5, [xl, zl] = lat(s, -1.25), [xr, zr] = lat(s, 1.25); pos.push(xl, .012, zl, xr, .012, zr); uv.push(0, s / 2.2, 1, s / 2.2); if (i < N) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); } }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx); g.computeVertexNormals();
  const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({map: pathTex, bumpMap: pathTex, bumpScale: 2.5, roughness: .95, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2}));
  m.receiveShadow = true; scene.add(m);
  const stones = [];
  for (const side of [-1, 1]) for (let s = 0; s < ZE - 3; s += rr(.28, .4)) { const [x, z] = lat(s, side * (1.32 + rr(-.06, .1))); stones.push({x, y: .03, z, sx: rr(.1, .2), sy: rr(.07, .12), ry: rr(0, 3), c: new THREE.Color(pick(['#b7a98c', '#9e9482', '#cbbd9c', '#8d8575']))}); }
  const sm2 = build(new THREE.IcosahedronGeometry(1, 1), new THREE.MeshStandardMaterial({roughness: .9}), stones, true);
}

/* ---------- plants ---------- */
function blade(w, l, curl, sw = 2, sl = 4) {
  const pos = [], idx = [];
  for (let i = 0; i <= sl; i++) {
    const v = i / sl, a = curl * v, wd = w * Math.pow(Math.sin(Math.PI * (.15 + .85 * v)), .55), cy = l * v * Math.cos(a * .5), cz = l * v * Math.sin(a * .5);
    for (let j = 0; j <= sw; j++) { const u = j / sw - .5; pos.push(u * wd, cy, cz + u * u * wd * 1.4); }
  }
  for (let i = 0; i < sl; i++) for (let j = 0; j < sw; j++) { const a = i * (sw + 1) + j, b = a + 1, c = a + sw + 1, d = c + 1; idx.push(a, c, b, b, c, d); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
function paint(g, c0, c1, keep) {
  const p = g.attributes.position, n = p.count, col = new Float32Array(n * 3), kp = new Float32Array(n).fill(keep ? 1 : 0);
  g.computeBoundingBox(); const y0 = g.boundingBox.min.y, y1 = g.boundingBox.max.y, a = new THREE.Color(c0), b = new THREE.Color(c1), t = new THREE.Color();
  for (let i = 0; i < n; i++) { t.lerpColors(a, b, (p.getY(i) - y0) / Math.max(1e-4, y1 - y0)); col[i * 3] = t.r; col[i * 3 + 1] = t.g; col[i * 3 + 2] = t.b; }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.setAttribute('aKeep', new THREE.BufferAttribute(kp, 1)); return g;
}
function flowerGeo(kind) {
  const P = [];
  const st = new THREE.CylinderGeometry(.007, .012, 1, 5, 4); st.deleteAttribute('uv'); st.translate(0, .5, 0); P.push(paint(st, '#3d6a2d', '#5f9a3f', 1));
  const lf = (ang, y, sz) => { const g = paint(blade(.07 * sz, .3 * sz, .7), '#386a2a', '#6aa545', 1); g.rotateX(.9); g.rotateY(ang); g.translate(0, y, 0); P.push(g); };
  lf(0, .12, 1); lf(2.6, .2, .85); if (kind !== 'spike') lf(4.4, .08, .9);
  const head = (n, w, l, tilt, curl, y, c0, c1, jit = .2, r0 = 0) => { for (let k = 0; k < n; k++) { const g = paint(blade(w, l, curl), c0, c1, 0); g.translate(0, 0, r0); g.rotateX(tilt + (R() - .5) * jit); g.rotateY(k * 6.2832 / n + (R() - .5) * .2); g.translate(0, y, 0); P.push(g); } };
  const disc = (r, y, c0, c1) => { const g = new THREE.CylinderGeometry(r, r * 1.05, .035, 12); g.deleteAttribute('uv'); g.translate(0, y, 0); P.push(paint(g, c0, c1, 1)); };
  if (kind === 'daisy') { head(12, .06, .17, 1.3, .6, 1, '#fff2a0', '#ffffff'); disc(.045, 1.012, '#c88a10', '#e8b020'); }
  else if (kind === 'sun') { head(20, .05, .2, 1.2, .5, 1, '#ffb300', '#ffe066'); disc(.11, 1.01, '#2e1b0c', '#4a2f17'); }
  else if (kind === 'rose') { head(5, .06, .12, .15, 1.2, .98, '#b0b0b0', '#ffffff'); head(6, .075, .14, .5, .9, .97, '#c0c0c0', '#ffffff'); head(8, .09, .16, .95, .7, .96, '#d0d0d0', '#ffffff'); }
  else if (kind === 'tulip') { head(6, .085, .2, .28, -.5, .88, '#cfcfcf', '#ffffff', .1, .01); head(3, .06, .17, .1, -.2, .88, '#bbbbbb', '#ffffff', .1); }
  else for (let i = 0; i < 26; i++) { const t = i / 25, y = .6 + .4 * t, sz = 1 - .55 * t; for (const a2 of [0, Math.PI]) { const g = paint(blade(.04 * sz, .075 * sz, .8, 2, 3), '#bbbbbb', '#ffffff', 0); g.rotateX(1); g.translate(0, 0, .012); g.rotateY(i * 2.4 + a2); g.translate(0, y, 0); P.push(g); } }
  return mergeGeometries(P);
}
const flowerMat = new THREE.MeshStandardMaterial({vertexColors: true, side: THREE.DoubleSide, roughness: .55}); patch(flowerMat, 'plant');
const grassMat = new THREE.MeshStandardMaterial({vertexColors: true, side: THREE.DoubleSide, roughness: .85}); patch(grassMat, 'plant');
const KINDS = ['daisy', 'rose', 'tulip', 'spike', 'sun'];
const PAL = {daisy: ['#ffffff', '#fff3c4', '#ffd1e0'], rose: ['#f6a5c0', '#e8607a', '#ffc7a0', '#fff1f4', '#d8456a'], tulip: ['#e24a5f', '#ffd45a', '#ff9a5a', '#b27be0', '#f6a5c0'], spike: ['#8f6fdc', '#6d86ff', '#b49af0'], sun: ['#ffc928', '#ffb300']};
const HT = {daisy: [.35, .6], rose: [.4, .65], tulip: [.45, .7], spike: [.7, 1.2], sun: [1, 1.5]};
const lists = Object.fromEntries(KINDS.map(k => [k, []]));
for (let i = 0; i < 3900 * Q; i++) {
  const s = rr(1, ZE + 3), [x, z] = lat(s, (1.7 + Math.pow(R(), 1.6) * 11) * (R() < .5 ? -1 : 1)); if (bad(x, z)) continue;
  const cell = hash(Math.floor(x / 2.4), Math.floor(z / 2.4)), kind = R() < .75 ? KINDS[Math.floor(cell * 5)] : pick(KINDS), pal = PAL[kind];
  const c = new THREE.Color(R() < .75 ? pal[Math.floor(hash(cell * 9.1, 3.3) * pal.length)] : pick(pal)); c.offsetHSL(rr(-.02, .02), rr(-.05, .05), rr(-.05, .05));
  lists[kind].push({x, z, s: rr(...HT[kind]), ry: rr(0, 6.28), rx: rr(-.1, .1), rz: rr(-.1, .1), c});
}
KINDS.forEach(k => build(flowerGeo(k), flowerMat, lists[k]));
{
  const gg = mergeGeometries([0, 1, 2].map(i => { const g = paint(blade(.05, 1, .8 + R() * .5, 1, 5), '#3b5a22', '#b8d070', 0); g.rotateX(.12 + R() * .3); g.rotateY(i * 2.1 + R()); g.translate((R() - .5) * .08, 0, (R() - .5) * .08); return g; }));
  const items = [];
  for (let i = 0; i < 44000 * Q; i++) { const s = rr(-3, ZE + 8), [x, z] = lat(s, (1.45 + Math.pow(R(), 1.6) * 18) * (R() < .5 ? -1 : 1)); if (bad(x, z)) continue; items.push({x, z, sx: rr(.8, 1.5), sy: rr(.28, .6), ry: rr(0, 6.28), c: new THREE.Color().setHSL(.23 + rr(-.02, .03), rr(.45, .65), rr(.5, .78))}); }
  build(gg, grassMat, items);
}

/* ---------- trees and bushes (alpha-card foliage) ---------- */
const leafTex = canvasTex(256, 256, c => {
  for (let pass = 0; pass < 2; pass++) for (let i = 0; i < (pass ? 70 : 40); i++) {
    const l = rr(22, 38) * (pass ? 1 : 1.2); c.save(); c.translate(rr(0, 256), rr(0, 256)); c.rotate(rr(0, 6.28));
    c.fillStyle = pass ? pick(['#4f8236', '#628f3f', '#76a24a', '#5a8c3a']) : pick(['#2b4f1f', '#33591f']);
    c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(l * .5, -l * .3, l, 0); c.quadraticCurveTo(l * .5, l * .3, 0, 0); c.fill();
    c.strokeStyle = 'rgba(255,255,220,.25)'; c.beginPath(); c.moveTo(0, 0); c.lineTo(l * .9, 0); c.stroke(); c.restore();
  }
}, [1, 1]);
const blosTex = canvasTex(256, 256, c => {
  for (let i = 0; i < 46; i++) {
    const x = rr(14, 242), y = rr(14, 242), r = rr(12, 19), a0 = rr(0, 6.28); c.fillStyle = 'rgba(120,90,100,.35)'; c.beginPath(); c.arc(x + 1, y + 2, r * 1.05, 0, 7); c.fill();
    for (let k = 0; k < 5; k++) { const a = a0 + k * 1.2566; c.fillStyle = pick(['#ffffff', '#fff3f6', '#fbe0e8']); c.beginPath(); c.ellipse(x + Math.cos(a) * r * .55, y + Math.sin(a) * r * .55, r * .55, r * .38, a, 0, 7); c.fill(); }
    c.fillStyle = '#d9577a'; c.beginPath(); c.arc(x, y, r * .2, 0, 7); c.fill();
  }
}, [1, 1]);
const cardGeo = new THREE.PlaneGeometry(1, 1);
const leafMat = new THREE.MeshStandardMaterial({map: leafTex, alphaTest: .5, side: THREE.DoubleSide, roughness: .8}); patch(leafMat, 'card');
const blosMat = new THREE.MeshStandardMaterial({map: blosTex, alphaTest: .5, side: THREE.DoubleSide, roughness: .8}); patch(blosMat, 'card');
const leaves = [], blos = [], trunks = [], q = new THREE.Quaternion(), qr = new THREE.Quaternion(), V = new THREE.Vector3(), Zv = new THREE.Vector3(0, 0, 1);
const leafTint = () => new THREE.Color().setHSL(.24 + R() * .06, .4 + R() * .25, .32 + R() * .22);
const blosTint = () => new THREE.Color().setHSL(rr(.92, .99), rr(.3, .8), rr(.78, .93));
const whiteTint = () => new THREE.Color().setHSL(rr(.1, .6), rr(0, .25), rr(.9, 1));
function card(arr, cx, cy, cz, r0, sz, sq, tint, minY) {
  V.set(R() * 2 - 1, (R() * 2 - 1) * sq, R() * 2 - 1).normalize(); const r = r0 * (.55 + .45 * R()); let y = cy + V.y * r; if (y < minY) y = minY + R() * .2;
  q.setFromUnitVectors(Zv, V); qr.setFromAxisAngle(Zv, R() * 6.28); arr.push({x: cx + V.x * r, y, z: cz + V.z * r, s: sz * (.8 + .5 * R()), q: q.clone().multiply(qr), c: tint()});
}
function tree(x, z) {
  const H = rr(2.3, 3.4), Rr = rr(2.3, 3.3), cy = H + Rr * .5, bl = R() < .4, n = Math.floor(150 * Math.max(Q, .65));
  trunks.push({x, z, sx: rr(.8, 1.2), sy: cy, ry: 0});
  for (let i = 0; i < n; i++) { const isB = bl && i > n * .3; card(isB ? blos : leaves, x, cy, z, Rr, isB ? rr(.8, 1.2) : rr(1.1, 1.8), .8, isB ? blosTint : leafTint, 1.6); }
}
for (let s = 4; s < ZE + 14; s += rr(3.5, 6)) for (const sd of [-1, 1]) { const [x, z] = lat(s, sd * rr(7, 16)); if (!bad(x, z)) tree(x, z); }
for (let s = -8; s < ZE + 22; s += 4.5) for (const sd of [-1, 1]) { const [x, z] = lat(s, sd * rr(24, 36)); tree(x, z); }
for (let i = 0; i < 12; i++) tree(rr(-16, 16), -(ZE + rr(6, 18)));
for (let i = 0; i < 40; i++) {
  const s = rr(3, ZE), [x, z] = lat(s, (R() < .5 ? -1 : 1) * rr(2.4, 10)); if (bad(x, z)) continue;
  const r0 = rr(.55, 1.0), fl = R() < .45;
  for (let k = 0; k < 30; k++) card(leaves, x, .55 * r0, z, r0, rr(.5, .9), .6, leafTint, .12);
  if (fl) { const t = R() < .5 ? whiteTint : blosTint; for (let k = 0; k < 20; k++) card(blos, x, .55 * r0, z, r0 * 1.05, rr(.35, .6), .6, t, .2); }
}
build(cardGeo, leafMat, leaves); build(cardGeo, blosMat, blos);
const trunkGeo = new THREE.CylinderGeometry(.11, .2, 1, 8).translate(0, .5, 0);
build(trunkGeo, new THREE.MeshStandardMaterial({color: 0x6d5a45, roughness: 1}), trunks, true);

/* ---------- gazebo ---------- */
const plank = canvasTex(256, 256, (c, w, h) => { for (let i = 0; i < 16; i++) { c.fillStyle = pick(['#d8c4a0', '#cdb892', '#e0cfae', '#c8b38c']); c.fillRect(0, i * 16, w, 15); c.fillStyle = 'rgba(80,60,30,.35)'; c.fillRect(0, i * 16 + 15, w, 1); } for (let i = 0; i < 700; i++) { c.fillStyle = 'rgba(90,65,35,.12)'; c.fillRect(rr(0, w), rr(0, h), rr(6, 30), 1); } }, [2, 2]);
const shingle = canvasTex(256, 256, (c, w, h) => { for (let y = 0; y < 8; y++) for (let x = -1; x < 8; x++) { const ox = (y % 2) * 16; c.fillStyle = pick(['#ffffff', '#f0f0f0', '#e3e3e3', '#fafafa']); c.beginPath(); c.roundRect(x * 32 + ox, y * 32, 31, 36, [0, 0, 12, 12]); c.fill(); c.strokeStyle = 'rgba(0,0,0,.25)'; c.stroke(); } }, [6, 3]);
const gz = new THREE.Group(); gz.position.set(0, 0, -ZE); scene.add(gz);
const white = new THREE.MeshStandardMaterial({color: 0xf7f2e8, roughness: .5});
const woodM = new THREE.MeshStandardMaterial({map: plank, roughness: .75});
const roofM = new THREE.MeshStandardMaterial({map: shingle, color: 0x8fb09a, roughness: .7, side: THREE.DoubleSide});
const addM = (p, g, m, x, y, z, ry = 0) => { const o = new THREE.Mesh(g, m); o.position.set(x, y, z); o.rotation.y = ry; o.castShadow = o.receiveShadow = true; p.add(o); return o; };
addM(gz, new THREE.CylinderGeometry(3.05, 3.15, .3, 8), woodM, 0, .15, 0, Math.PI / 8);
addM(gz, new THREE.BoxGeometry(2.3, .15, .8), woodM, 0, .075, 3.5);
addM(gz, new THREE.CylinderGeometry(3.5, 3.5, .22, 8), white, 0, 3.15, 0, Math.PI / 8);
addM(gz, new THREE.ConeGeometry(3.55, 2.2, 8, 1, true), roofM, 0, 4.36, 0, Math.PI / 8);
addM(gz, new THREE.ConeGeometry(3.4, 2.1, 8, 1, true), white.clone(), 0, 4.3, 0, Math.PI / 8).material.side = THREE.BackSide;
addM(gz, new THREE.SphereGeometry(.13, 12, 8), white, 0, 5.5, 0); addM(gz, new THREE.ConeGeometry(.05, .5, 8), white, 0, 5.8, 0);
const rp = 2.65, posts = [];
for (let k = 0; k < 8; k++) { const th = Math.PI / 8 + k * Math.PI / 4, px = rp * Math.sin(th), pz = rp * Math.cos(th); posts.push([px, pz]);
  addM(gz, new THREE.CylinderGeometry(.085, .1, 2.85, 14), white, px, 1.725, pz); addM(gz, new THREE.BoxGeometry(.28, .2, .28), white, px, .4, pz, th); addM(gz, new THREE.BoxGeometry(.3, .12, .3), white, px, 3.05, pz, th); }
for (let k = 0; k < 7; k++) {
  const [x0, z0] = posts[k], [x1, z1] = posts[k + 1], len = Math.hypot(x1 - x0, z1 - z0), g = new THREE.Group();
  g.position.set((x0 + x1) / 2, 0, (z0 + z1) / 2); g.rotation.y = -Math.atan2(z1 - z0, x1 - x0); gz.add(g);
  addM(g, new THREE.BoxGeometry(len, .07, .08), white, 0, 1.15, 0); addM(g, new THREE.BoxGeometry(len, .06, .06), white, 0, .5, 0);
  for (let i = 0; i < 9; i++) addM(g, new THREE.BoxGeometry(.03, .65, .03), white, (i / 8 - .5) * len * .9, .825, 0);
}
const budGeo = new THREE.IcosahedronGeometry(1, 1), budMat = new THREE.MeshStandardMaterial({roughness: .5});
const buds = [], leafB = [], bc = ['#f6a5c0', '#ffffff', '#ffd45a', '#ff8d74', '#ab90e6', '#e8607a'];
const bud = (x, y, z, r) => { buds.push({x, y: y, z: z + -ZE, s: r, c: new THREE.Color(pick(bc))}); leafB.push({x: x + rr(-.04, .04), y: y - .03, z: z - ZE + rr(-.04, .04), sx: r * 1.8, sy: r * .9, c: new THREE.Color().setHSL(.27, .45, rr(.25, .4)), ry: rr(0, 6)}); };
for (let k = 0; k < 8; k++) { const [x0, z0] = posts[k], [x1, z1] = posts[(k + 1) % 8]; for (let i = 0; i <= 18; i++) { const t = i / 18; bud(x0 + (x1 - x0) * t, 2.95 - .38 * (1 - (2 * t - 1) ** 2) + rr(-.03, .03), z0 + (z1 - z0) * t, rr(.05, .085)); } for (let j = 0; j < 10; j++) bud(x0 + Math.sin(j * 1.7) * .11, .6 + j * .22, z0 + Math.cos(j * 1.7) * .11, rr(.045, .07)); }
for (let i = 0; i <= 44; i++) { const a = i / 44 * Math.PI; bud(Math.cos(a) * 1.0, 1.3 + Math.sin(a) * 1.0, -2.0, rr(.08, .13)); }
for (let j = 0; j < 12; j++) for (const sx of [-1, 1]) bud(sx * 1.0, .35 + j * .08, -2.0, rr(.08, .12));
build(budGeo, budMat, buds); build(budGeo, new THREE.MeshStandardMaterial({roughness: .8}), leafB);
addM(gz, new THREE.TorusGeometry(1, .035, 8, 28, Math.PI), white, 0, 1.3, -2.0); [-1, 1].forEach(sx => addM(gz, new THREE.CylinderGeometry(.035, .035, 1, 8), white, sx, .8, -2.0));
const lightMat = new THREE.MeshBasicMaterial({color: new THREE.Color(3, 2.3, 1.1), toneMapped: false}), lights = new THREE.InstancedMesh(new THREE.SphereGeometry(.035, 8, 6), lightMat, 64);
for (let i = 0; i < 64; i++) { const a = i / 64 * 6.2832; dm.position.set(Math.sin(a) * 3.45, 2.98 + Math.sin(a * 8) * .03, -ZE + Math.cos(a) * 3.45); dm.rotation.set(0, 0, 0); dm.scale.setScalar(1); dm.updateMatrix(); lights.setMatrixAt(i, dm.matrix); }
scene.add(lights);
const inLight = new THREE.PointLight(0xffd9a0, 5, 9, 2); inLight.position.set(0, 2.6, -ZE + .8); scene.add(inLight);

/* ---------- easel + invitation ---------- */
const inv = document.createElement('canvas'); inv.width = 900; inv.height = 1200;
const invTex = new THREE.CanvasTexture(inv); invTex.colorSpace = THREE.SRGBColorSpace; invTex.anisotropy = 16;
function bloom(c, x, y, r, col) { c.fillStyle = col; for (let i = 0; i < 8; i++) { const a = i * .785; c.beginPath(); c.ellipse(x + Math.cos(a) * r * .55, y + Math.sin(a) * r * .55, r * .5, r * .28, a, 0, 7); c.fill(); } c.fillStyle = '#e9a825'; c.beginPath(); c.arc(x, y, r * .3, 0, 7); c.fill(); }
function cluster2(c, x, y, rot) { c.save(); c.translate(x, y); c.rotate(rot); c.fillStyle = '#8fb08a'; for (let i = 0; i < 7; i++) { c.save(); c.rotate(-.2 + i * .32); c.beginPath(); c.ellipse(70 + i * 8, 0, 46, 11, 0, 0, 7); c.fill(); c.restore(); }
  [[40, 10, 26, '#f4a6c0'], [85, -40, 20, '#fffdf5'], [100, 30, 22, '#ffd45a'], [60, 60, 17, '#ab90e6'], [130, -5, 15, '#ff8d74'], [22, 52, 14, '#fffdf5']].forEach(a => bloom(c, a[0], a[1], a[2], a[3])); c.restore(); }
function paintInvite() {
  const c = inv.getContext('2d'); c.setTransform(1.5, 0, 0, 1.5, 0, 0); c.clearRect(0, 0, 600, 800);
  const g = c.createLinearGradient(0, 0, 600, 800); g.addColorStop(0, '#fffcf3'); g.addColorStop(1, '#f7edd8'); c.fillStyle = g; c.fillRect(0, 0, 600, 800);
  c.strokeStyle = '#c9a45a'; c.lineWidth = 2; c.strokeRect(22, 22, 556, 756); c.lineWidth = 1; c.strokeRect(32, 32, 536, 736);
  cluster2(c, 26, 26, 0); cluster2(c, 574, 774, Math.PI); c.textAlign = 'center';
  const L = (t, y, f, sp) => { c.font = f; try { c.letterSpacing = sp || '0px'; } catch (e) {} c.fillText(t, 300, y); };
  const SER = '"Cormorant Garamond",Georgia,serif';
  c.fillStyle = '#4b4a3a'; L('together with their families', 182, `italic 500 25px ${SER}`, '1px');
  c.fillStyle = '#a94a63'; L('Amara', 290, '94px "Pinyon Script",cursive');
  c.fillStyle = '#4b4a3a'; L('and', 345, `italic 500 34px ${SER}`);
  c.fillStyle = '#a94a63'; L('Tobi', 438, '94px "Pinyon Script",cursive');
  c.fillStyle = '#4b4a3a'; L('invite you to celebrate their wedding', 500, `italic 500 25px ${SER}`);
  c.strokeStyle = '#c9a45a'; c.beginPath(); c.moveTo(190, 548); c.lineTo(275, 548); c.moveTo(325, 548); c.lineTo(410, 548); c.stroke(); bloom(c, 300, 548, 11, '#f4a6c0');
  c.fillStyle = '#4b4a3a'; L('Saturday, 14 June 2027', 612, `600 31px ${SER}`, '1.5px'); L('at four o’clock in the afternoon', 652, `italic 500 24px ${SER}`); L('The Garden Pavilion', 700, `600 26px ${SER}`, '1px');
  invTex.needsUpdate = true;
}
paintInvite();
Promise.all(['94px "Pinyon Script"', 'italic 500 25px "Cormorant Garamond"', '600 31px "Cormorant Garamond"'].map(f => document.fonts.load(f))).then(paintInvite).catch(() => {});
{
  const e = new THREE.Group(); e.position.set(0, .3, -ZE - .1); scene.add(e);
  const wd = new THREE.MeshStandardMaterial({color: 0x8d6b46, roughness: .75}), up = new THREE.Vector3(0, 1, 0);
  const leg = (a, b, r) => { const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b), d = B.clone().sub(A), m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, d.length(), 8), wd); m.position.copy(A).add(B).multiplyScalar(.5); m.quaternion.setFromUnitVectors(up, d.normalize()); m.castShadow = true; e.add(m); };
  leg([-.7, 0, .35], [-.12, 2.4, 0], .03); leg([.7, 0, .35], [.12, 2.4, 0], .03); leg([0, 0, -.9], [0, 2.3, -.05], .03);
  addM(e, new THREE.BoxGeometry(1.7, .06, .08), wd, 0, .52, .06); addM(e, new THREE.BoxGeometry(1.0, .05, .06), wd, 0, 2.3, -.02);
  addM(e, new THREE.BoxGeometry(1.26, 1.66, .03), new THREE.MeshStandardMaterial({color: 0xfbf7ee, roughness: .8}), 0, 1.38, 0);
  const pl = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.6), new THREE.MeshStandardMaterial({map: invTex, roughness: .85})); pl.position.set(0, 1.38, .02); pl.receiveShadow = true; e.add(pl);
}

/* ---------- life: dust, butterflies ---------- */
const dn = 260, dp = new Float32Array(dn * 3), dg = new THREE.BufferGeometry();
const dot = canvasTex(64, 64, (c, w, h) => { const g = c.createRadialGradient(32, 32, 0, 32, 32, 32); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h); }, [1, 1]);
for (let i = 0; i < dn; i++) { dp[i * 3] = rr(-10, 10); dp[i * 3 + 1] = rr(.2, 4); dp[i * 3 + 2] = rr(-20, 4); }
dg.setAttribute('position', new THREE.BufferAttribute(dp, 3));
const dust = new THREE.Points(dg, new THREE.PointsMaterial({map: dot, size: .06, transparent: true, opacity: .55, depthWrite: false, blending: THREE.AdditiveBlending, color: 0xfff2cc})); dust.frustumCulled = false; scene.add(dust);
const bfs = ['#ffd45a', '#ff9db8', '#ffffff', '#9fc0ff', '#ffb27a'].map((c, i) => {
  const g = new THREE.Group(), m = new THREE.MeshBasicMaterial({color: c, side: THREE.DoubleSide}), wg = new THREE.CircleGeometry(.05, 12); wg.scale(1, .8, 1); wg.rotateX(-Math.PI / 2);
  const a = new THREE.Mesh(wg.clone().translate(.05, 0, 0), m), b = new THREE.Mesh(wg.clone().translate(-.05, 0, 0), m); g.add(a, b); g.userData = {a, b, i}; scene.add(g); return g;
});

/* ---------- post-processing ---------- */
const composer = new EffectComposer(renderer, new THREE.WebGLRenderTarget(4, 4, {type: THREE.HalfFloatType, samples: 4}));
composer.addPass(new RenderPass(scene, camera));
composer.addPass(new UnrealBloomPass(new THREE.Vector2(4, 4), .35, .7, .95));
// warm late-afternoon colour grade
composer.addPass(new ShaderPass({
  uniforms: {tDiffuse: {value: null}},
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; varying vec2 vUv;
    void main(){ vec4 c = texture2D(tDiffuse, vUv); vec3 col = c.rgb;
      float l = dot(col, vec3(.2126, .7152, .0722));
      col *= vec3(1.1, 1.0, .82);
      col = mix(vec3(l), col, 1.12);
      col += vec3(.012, .005, -.004) * (1.0 - smoothstep(0.0, .4, l));
      col = mix(col, col * vec3(1.06, .98, .9), smoothstep(.5, 2.5, l));
      vec2 d = vUv - .5; col *= 1.0 - dot(d, d) * .85;
      gl_FragColor = vec4(col, c.a); }`
}));
composer.addPass(new OutputPass());
function resize() {
  const W = innerWidth, H = innerHeight, pr = Math.min(devicePixelRatio || 1, COARSE ? 1.5 : 1.75);
  renderer.setPixelRatio(pr); renderer.setSize(W, H, false); composer.setPixelRatio(pr); composer.setSize(W, H);
  camera.aspect = W / H; camera.fov = W / H < .9 ? 68 : 50; camera.updateProjectionMatrix(); finalS = ZE + .1 - (W / H < .9 ? 2.8 : 2.3);
}
addEventListener('resize', resize); resize();

/* ---------- music ---------- */
const audio = new Audio(MUSIC_SRC); audio.loop = true; audio.volume = 0; audio.preload = 'auto';
let musicOn = false, muted = false;
const playMusic = () => { musicOn = true; audio.play().catch(() => {}); };
document.addEventListener('visibilitychange', () => { if (document.hidden) audio.pause(); else if (musicOn) audio.play().catch(() => {}); });
addEventListener('pagehide', () => audio.pause());

/* ---------- camera ride ---------- */
const intro = document.getElementById('intro'), endEl = document.getElementById('end'), hintEl = document.getElementById('hint'), sndBtn = document.getElementById('snd');
// speed profile: gentle start, steady walk, long ease-out as we reach the invitation
const NT = 2000, TAB = (() => { const t = [0]; let a = 0; for (let i = 1; i <= NT; i++) { const u = i / NT; a += sm(u / .1) * Math.pow(1 - sm((u - .55) / .45), 1.15); t.push(a); } return t.map(v => v / a); })();
function prog(u) { const x = clamp(u) * NT, i = Math.min(NT - 1, Math.floor(x)); return [TAB[i] + (TAB[i + 1] - TAB[i]) * (x - i), (TAB[i + 1] - TAB[i]) * NT]; }
let state = 'idle', t0 = 0, s0 = S_START, s = S_START, first = true;
const lookT = new THREE.Vector3(), des = new THREE.Vector3(), fwd = new THREE.Vector3(), INV = new THREE.Vector3(0, 1.68, -ZE - .1), clock = new THREE.Clock();
const AX = new THREE.Vector3(0, 1, 0), qY = new THREE.Quaternion();
const sX = new THREE.Vector3().crossVectors(AX, sunDir).normalize(), sY = new THREE.Vector3().crossVectors(sunDir, sX);
function snap(v) { const a = v.dot(sX), b = v.dot(sY), tx = 60 / 2048; v.addScaledVector(sX, Math.round(a / tx) * tx - a).addScaledVector(sY, Math.round(b / tx) * tx - b); }

/* drag to look around */
let drag = false, lx = 0, ly = 0, ty = 0, tp = 0, uy = 0, up = 0;
canvas.addEventListener('pointerdown', e => { drag = true; lx = e.clientX; ly = e.clientY; canvas.setPointerCapture(e.pointerId); canvas.classList.add('grab'); });
canvas.addEventListener('pointermove', e => { if (!drag) return; const k = camera.fov * Math.PI / 180 / innerHeight * 1.15; ty = clamp(ty + (e.clientX - lx) * k, -2.6, 2.6); tp = clamp(tp + (e.clientY - ly) * k, -.9, .9); lx = e.clientX; ly = e.clientY; });
const endDrag = () => { drag = false; canvas.classList.remove('grab'); };
canvas.addEventListener('pointerup', endDrag); canvas.addEventListener('pointercancel', endDrag);

document.getElementById('go').addEventListener('click', () => {
  intro.classList.add('hide'); s0 = s; t0 = performance.now() + 400; state = 'walk'; playMusic(); sndBtn.classList.add('show');
  setTimeout(() => hintEl.classList.add('show'), 1500); setTimeout(() => hintEl.classList.remove('show'), 8000);
});
document.getElementById('again').addEventListener('click', () => { endEl.classList.remove('show'); s0 = S_START; s = S_START; ty = tp = 0; t0 = performance.now() + 200; state = 'walk'; });
sndBtn.addEventListener('click', () => { muted = !muted; audio.muted = muted; sndBtn.classList.toggle('off', muted); sndBtn.setAttribute('aria-pressed', muted); });

function tick() {
  const dt = Math.min(.05, clock.getDelta()), t = clock.elapsedTime; U.uTime.value = t * (RM ? .35 : 1);
  let spd = 0;
  if (state === 'walk') { const u = clamp((performance.now() - t0) / DUR), [f, df] = prog(u); s = s0 + (finalS - s0) * f; spd = (finalS - s0) * df / (DUR / 1000); if (u >= 1) { state = 'done'; endEl.classList.add('show'); } }
  else if (state === 'idle') s = S_START + Math.sin(t * .35) * .12;
  const lookIn = sm((s - (ZE - 22)) / (finalS - (ZE - 22))), amp = RM ? 0 : clamp(spd / 2.4) * (1 - lookIn * .8), ph = s * 8.2;
  camera.position.set(pathX(s) + Math.sin(ph * .5) * .008 * amp, CAM_H + Math.sin(ph) * .014 * amp + Math.sin(t * .8) * .004, -s);
  des.set(pathX(s + 7), 1.35, -(s + 7)).lerp(INV, lookIn);
  if (first) { lookT.copy(des); first = false; } lookT.lerp(des, 1 - Math.exp(-dt * 2.2));
  const rst = state === 'walk' ? sm((s - (ZE - 24)) / 14) : 0;
  if (!drag && rst > 0) { const d = Math.exp(-dt * (.4 + rst * 3)); ty *= d; tp *= d; }
  uy += (ty - uy) * (1 - Math.exp(-dt * 9)); up += (tp - up) * (1 - Math.exp(-dt * 9));
  camera.lookAt(lookT); camera.quaternion.premultiply(qY.setFromAxisAngle(AX, uy)); camera.rotateX(up); camera.rotateZ(Math.sin(ph * .5) * .0025 * amp);
  fwd.copy(lookT).sub(camera.position).normalize();
  sun.target.position.copy(camera.position).addScaledVector(fwd, 18); snap(sun.target.position); sun.position.copy(sun.target.position).addScaledVector(sunDir, 80);
  const vt = musicOn && !muted ? .7 : 0; audio.volume = clamp(audio.volume + (vt - audio.volume) * (1 - Math.exp(-dt * 1.2)));
  const c = camera.position;
  for (let i = 0; i < dn; i++) { const k = i * 3; dp[k] += (Math.sin(t * .3 + i) * .05 + .05) * dt; dp[k + 1] += Math.sin(t * .5 + i * 2) * .03 * dt; dp[k + 2] += Math.cos(t * .25 + i) * .04 * dt;
    if (dp[k] - c.x > 10) dp[k] -= 20; else if (dp[k] - c.x < -10) dp[k] += 20; if (dp[k + 1] > 4) dp[k + 1] = .2; if (dp[k + 2] - c.z > 6) dp[k + 2] -= 26; else if (dp[k + 2] - c.z < -20) dp[k + 2] += 26; }
  dg.attributes.position.needsUpdate = true;
  for (const b of bfs) { const i = b.userData.i, bs = s + 5 + i * 5 + Math.sin(t * .3 + i) * 2, f = Math.sin(t * 26 + i * 2) * .9 + .3; if (bs > ZE - 3) { b.visible = false; continue; } b.visible = true;
    b.position.set(pathX(bs) + Math.sin(t * .5 + i * 2) * 2.5, .6 + (Math.sin(t * .9 + i * 1.3) + 1) * .35, -bs); b.rotation.y = Math.sin(t * .5 + i * 2) * 1.2; b.userData.a.rotation.z = f; b.userData.b.rotation.z = -f; }
  composer.render(); requestAnimationFrame(tick);
}
tick();
